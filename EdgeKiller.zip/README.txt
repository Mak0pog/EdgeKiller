Thanks for downloading EdgeKiller!

STEP BY STEP GUIDE:

1. Go into the folder with your browsers name. (If your browser isn’t on the list, DM me on Discord [https://bit.ly/makopogdiscord] and I will make one for you )

2. Copy "msedge.exe" to "C:\Program Files (x86)\Microsoft\Edge\Application" and "C:\Program Files (x86)\Microsoft\Edge\Application\101... (in my case it’s 101.0.1210.39)"
If you will be prompted with replace question, make sure to click on "YES" for both directories. (administrator previlegies might be required)

3. You’re done. Enjoy!

